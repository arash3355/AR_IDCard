using UnityEngine;

public class PanelSwitcher : MonoBehaviour
{
    public GameObject PanelMain;
    public GameObject PanelAbout;

    public void ShowAbout()
    {
        PanelMain.SetActive(false);
        PanelAbout.SetActive(true);
    }

    public void ShowMain()
    {
        PanelAbout.SetActive(false);
        PanelMain.SetActive(true);
    }
}
