using UnityEngine;

public class PanelManager : MonoBehaviour
{
    public GameObject screenIG;
    public GameObject screenWA;
    public GameObject screenVideo;

    // Toggle IG
    public void ToggleIG()
    {
        screenIG.SetActive(!screenIG.activeSelf);
    }

    // Toggle WA
    public void ToggleWA()
    {
        screenWA.SetActive(!screenWA.activeSelf);
    }

    // Toggle Video
    public void ToggleVideo()
    {
        screenVideo.SetActive(!screenVideo.activeSelf);
    }
}
