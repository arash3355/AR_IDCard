using UnityEngine;

public class SosmedToggle : MonoBehaviour
{
    public GameObject panelSosmed;
    
    public void Toggle()
    {
        panelSosmed.SetActive(!panelSosmed.activeSelf);
    }
}
