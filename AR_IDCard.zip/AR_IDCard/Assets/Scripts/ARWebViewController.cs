using UnityEngine;
using UnityEngine.UI;
using WebView;

public class ARWebViewController : MonoBehaviour
{
    public WebViewManager webViewManager;

    public void OpenInstagram()
    {
        if (webViewManager != null)
        {
            webViewManager.LoadUrl("https://www.instagram.com/arash1112_/");
            webViewManager.enabled = true;
        }
    }

    public void OpenYouTube()
    {
        if (webViewManager != null)
        {
            webViewManager.LoadUrl("https://youtu.be/wQBOHvKr6bI");
            webViewManager.enabled = true;
        }
    }

    public void OpenWhatsApp()
    {
        if (webViewManager != null)
        {
            webViewManager.LoadUrl("https://wa.me/628990047009");
            webViewManager.enabled = true;
        }
    }

    public void CloseWebView()
    {
        if (webViewManager != null)
        {
            webViewManager.enabled = false;
        }
    }
}
