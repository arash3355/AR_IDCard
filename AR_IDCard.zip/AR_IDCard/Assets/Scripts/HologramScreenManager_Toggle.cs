using UnityEngine;

public class HologramScreenManager_Toggle : MonoBehaviour
{
    public GameObject screenVideo;
    public GameObject screenIG;
    public GameObject screenWA;

    GameObject currentActiveScreen = null;

    public void ToggleVideo()
    {
        Toggle(screenVideo);
    }

    public void ToggleIG()
    {
        Toggle(screenIG);
    }

    public void ToggleWA()
    {
        Toggle(screenWA);
    }

    void Toggle(GameObject target)
    {
        if (currentActiveScreen == target)
        {
            target.SetActive(false);
            currentActiveScreen = null;
        }
        else
        {
            // Matikan layar sebelumnya
            if (currentActiveScreen != null)
                currentActiveScreen.SetActive(false);

            // Aktifkan layar baru
            target.SetActive(true);
            currentActiveScreen = target;
        }
    }
}
