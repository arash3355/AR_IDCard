using UnityEngine;
using UnityEngine.UI;

public class IDCardPrefabController : MonoBehaviour
{
    public Button buttonIG;
    public Button buttonWA;
    public Button buttonYT;
    public ARWebViewController arWebViewController;

    void Awake()
    {
        // Hapus listener lama untuk menghindari tumpang tindih
        buttonIG.onClick.RemoveAllListeners();
        buttonWA.onClick.RemoveAllListeners();
        buttonYT.onClick.RemoveAllListeners();

        // Assign listener baru
        buttonIG.onClick.AddListener(() =>
        {
            Debug.Log("Button IG diklik!");
            arWebViewController.OpenInstagram();
        });

        buttonWA.onClick.AddListener(() =>
        {
            Debug.Log("Button WA diklik!");
            arWebViewController.OpenWhatsApp();
        });

        buttonYT.onClick.AddListener(() =>
        {
            Debug.Log("Button YT diklik!");
            arWebViewController.OpenYouTube();
        });
    }
}
