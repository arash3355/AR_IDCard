using UnityEngine;

public class SlidePanel : MonoBehaviour
{
    public RectTransform panel;        // Panel sosmed
    public Vector3 hiddenPos;          // Posisi di belakang card
    public Vector3 shownPos;           // Posisi muncul
    public float speed = 6f;

    private bool isShown = false;

    void Update()
    {
        panel.localPosition = Vector3.Lerp(
            panel.localPosition,
            isShown ? shownPos : hiddenPos,
            Time.deltaTime * speed
        );
    }

    public void TogglePanel()
    {
        isShown = !isShown;
    }
}
