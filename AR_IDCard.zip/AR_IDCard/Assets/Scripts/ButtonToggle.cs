using UnityEngine;

public class SosmedToggle : MonoBehaviour
{
    public GameObject panelSosmed;   // Panel tombol IG/WA/Video
    public GameObject screenIG;
    public GameObject screenWA;
    public GameObject screenVideo;

    public void Toggle()
    {
        // Jika panelSosmed sedang aktif → klik kedua kali
        if (panelSosmed.activeSelf)
        {
            // Matikan semua panel & layar
            panelSosmed.SetActive(false);
            screenIG.SetActive(false);
            screenWA.SetActive(false);
            screenVideo.SetActive(false);

            return;
        }

        // Klik pertama → tampilkan panel sosial media
        panelSosmed.SetActive(true);
    }
}
