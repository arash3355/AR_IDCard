using UnityEngine;

public class OpenLinks : MonoBehaviour
{
    public void OpenInstagram()
    {
        Application.OpenURL("https://www.instagram.com/arash1112_/");
    }

    public void OpenWhatsApp()
    {
        Application.OpenURL("https://wa.me/628990047009");
        // contoh: https://wa.me/6281234567890
    }

    public void OpenYouTube()
    {
        Application.OpenURL("https://youtu.be/wQBOHvKr6bI");
    }
}
